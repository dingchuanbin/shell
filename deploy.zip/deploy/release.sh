#!/bin/bash
source ~/.bash_profile
releaseapps=$*
jobname=deploy
for app in ${releaseapps[@]};
        do
                cd /opt/deploy/
		sysversion=`grep "${app}.version" *_version.properties|awk -F'_' '{print $2}'`
		echo ${sysversion} >.tmpversion
                if [[ -f /opt/deploy/scripts/${app}.yaml ]];then
                        sh deploy.sh ${app}
                elif [ ${app} == tq-admin_e ];then
                        rsync -av --delete -e "ssh -i dy-uat.pem" 139.9.115.211:/opt/appdata/default-nginx/webapps/tq-admin/* ./webapps/tq-admin --exclude=config.js
			rsync -av --delete ./webapps/tq-admin/* -e "ssh -i dy-rel.pem" 172.31.0.136:/opt/appdata/default-nginx-admin/webapps/tq-admin --exclude=config.js
		elif [ ${app} == tq-admin_m ];then
			rsync -av --delete -e "ssh -i dy-uat.pem" 139.9.115.211:/opt/appdata/default-nginx/webapps/tq-admin_m/* ./webapps/tq-admin_m --exclude=config.js
			rsync -av --delete ./webapps/tq-admin_m/* -e "ssh -i dy-rel.pem" 172.31.0.136:/opt/appdata/default-nginx/webapps/tq-admin_m --exclude=config.js
			rsync -av --delete ./webapps/tq-admin_m/* -e "ssh -i dy-rel.pem" 172.31.0.136:/opt/appdata/default-nginx/webapps/tq-admin_y --exclude=config.js
		elif [ ${app} == mobile-dy ];then
			rsync -av --delete -e "ssh -i dy-uat.pem" 139.9.115.211:/opt/appdata/default-nginx/webapps/mobile-dy/* ./webapps/mobile-dy --exclude=config.js
                        rsync -av --delete ./webapps/mobile-dy/* -e "ssh -i dy-rel.pem" 172.31.0.136:/opt/appdata/default-nginx/webapps/mobile-dy --exclude=config.js
		elif [ ${app} == client-dy ];then
			rsync -av --delete -e "ssh -i dy-uat.pem" 139.9.115.211:/opt/appdata/default-nginx/webapps/client-dy/* ./webapps/client-dy --exclude=config.js
                        rsync -av --delete ./webapps/client-dy/* -e "ssh -i dy-rel.pem" 172.31.0.136:/opt/appdata/default-nginx/webapps/client-dy --exclude=config.js
		else
                        echo  "工程不存在"
                fi
        done
echo "升级后版本对比"
sh diffversion.sh
#更新confluence页面版本
sh pub_confluence.sh

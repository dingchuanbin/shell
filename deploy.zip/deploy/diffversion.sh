rsync -a --delete -e "ssh -i /opt/deploy/dy-uat.pem" 139.9.115.211:/opt/deploy/runningversion ./moniversion
moniversion=`cat moniversion`
kubectl get deployment -o=jsonpath='{range .items[*]}{...image}{"\n"}'|grep -v -E "0/0|NAME|base-configserver|busybox|mongodb|nginx|redis|seata|zookeeper|rabbit|mongo|memcached|mysql|activemq"|awk -F'/' '{print $NF}'|uniq >runningversion
adminversion=`cat /opt/deploy/webapps/tq-admin/version`
admin_mversion=`cat /opt/deploy/webapps/tq-admin_m/version`
mobileversion=`cat /opt/deploy/webapps/mobile-dy/version`
clinetversion=`cat /opt/deploy/webapps/client-dy/version`
echo -e "tq-admin_e:${adminversion}\ntq-admin_m:${admin_mversion}\nmobile-dy:${mobileversion}\nclient-dy:${clinetversion}" >>./runningversion
>.waitupdatestr
for inmoni in ${moniversion[@]}
        do
                appinmoni=`echo ${inmoni}|awk -F':' '{print $1}'`
                appversioninmoni=`echo ${inmoni}|awk -F':' '{print $2}'`
		appversioninrel=`grep "^${appinmoni}:" runningversion|awk -F':' '{print $2}'`
		if [[ ${appversioninmoni} != ${appversioninrel}  ]];then
			echo "$appinmoni: $appversioninrel ----> $appversioninmoni"
			echo -e "<tr><td>${appinmoni}</td><td>${appversioninmoni}</td><td>${appversioninrel}</td></tr>\c" >>.waitupdatestr
		fi
        done

deployapps=($*)
sysversion=`cat /opt/deploy/.tmpversion`
cat init.conf|grep -v "^#" >.init_tmp.conf
env_namespace=`cat .init_tmp.conf|grep '^env_namespace'|cut -d = -f 2`
function init_replace(){
        while read line
                do
                        key=`echo $line|cut -d = -f 1`
                        value=`echo $line|cut -d = -f 2`
                        sed -i "s|{{ $key }}|`eval echo ${value}`|g" scripts/${appname}.yaml
                done < .init_tmp.conf
}

kubectl get namespace |grep ${env_namespace} >/dev/null
echo "部署"
for appname in ${deployapps[@]}
        do
                grep "^${appname}.version" *_${sysversion}_version.properties >/dev/null
                if [[ $? -eq 0 ]];then
                        sysid=$(grep "^${appname}.version" *_${sysversion}_version.properties -H|awk -F ":${appname}.version" '{print $1}'|awk -F '_' '{print $1}')
                        grep "^${sysid}_version" .init_tmp.conf
                        if [[ $? -eq 0 ]];then
                                versionout=$(grep "^${sysid}_version")
                                echo "统一版本号已经初始化${versionout}"
                        else
                                app_version=$(grep "^${appname}.version" *_${sysversion}_version.properties|awk -F '=' '{print $2}')
                                echo $app_version
                                sed -i "s|{{ ${sysid}_version }}|${app_version}|g" scripts/${appname}.yaml
                        fi
                fi
                init_replace
                kubectl apply -f scripts/${appname}.yaml
		rsync -a  scripts_tmp/${appname}.yaml ./scripts/
        done

restart_pod=`kubectl get pod|grep -v NAME|awk '{if ($4 != 0)print $1}'`
for pod in ${restart_pod[@]}
	do
		deployment_name=`kubectl get pod ${pod} -ojsonpath={.status.containerStatuses[*].name}`
		if [[  ! -n $deployment_list ]];then
			deployment_list=$deployment_name
		else
			deployment_list=($deployment_name,${deployment_list[*]})
		fi
	done
echo $deployment_list
